package com.example.understandingDI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnderstandingDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
